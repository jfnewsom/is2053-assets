# IS2053: Programming I — Week 12 Slide Guide
## Module 4, Week 3 | Chapter 9: Dictionaries and Sets (continued)
### "Smarter Code" — The Full Payoff

**Course:** IS2053 Programming I
**Instructor:** John Newsom, UT San Antonio
**Textbook:** Starting Out with Python, 6th Edition — Tony Gaddis
**Module Theme:** Smarter Code
**Week Focus:** Chapter 9 — Sets for unique tracking; TRIVIA dictionary replacing the coin-flip Destination Gate
**Assignment:** Lab 4.3: Data-Driven Texas (MASTER)

---

## Slide 1: Title Slide

### Key Points
- Module 4, Week 3: MASTER — the full payoff
- Chapter 9 — Sets and the TRIVIA Dictionary
- Week 12 | Spring 2026
- Bat City Collective | Deep in the Heart: A Lone Star Journey

### Instructor Script
"Welcome to Week 12, everyone — the MASTER week for Module 4. This is the third and final week of Smarter Code, and this week everything comes together. Last week you learned how dictionaries work and replaced your distance constants with a real data structure. This week you've got two moves left. First: sets. We talked about them briefly — this week you actually use them to track unique cities visited and unique hazards faced, and you'll see exactly why they're way cleaner than what you were doing before. Second — and this is the big one — that coin flip Destination Gate is finally dead. You're replacing it with a TRIVIA dictionary. Players have to earn their destination by answering a question correctly. No more luck. Knowledge wins."

### Key Terms
*(No new terms on the title slide — just set the tone)*

### Discussion Questions
1. How are you feeling coming into MASTER week — has Module 4 clicked for you, or are there pieces that still feel fuzzy?
2. What's one thing you built in Lab 4.2 that you're actually proud of?

---

## Slide 2: Where We Are — Module 4 Final Week

### Key Points
1. Module 4 had four pain points to fix; three are already done.
2. Pain 1 (Week 10): `.upper()` and `.strip()` — your input is clean.
3. Pain 2 (Week 11): `CITY_DISTANCES` dictionary — your data is organized.
4. Pain 3 (Week 12): Sets — unique tracking in one line, no loops.
5. Pain 4 (Week 12): TRIVIA gate — replace random luck with earned knowledge.

### Instructor Script
"Let me put this week in context. We came into Module 4 with four legitimate complaints about the codebase. Week 10, we killed the duplicate-case input problem. Week 11, we killed the 20-constant distance mess. This week we kill the last two. Sets solve the 'how do I track unique cities without a manual loop' problem in literally one line of code. And TRIVIA turns the Destination Gate from a coin flip — which is just random — into a knowledge check. The player has to know something about the city to get there. That's not just better design; it's actually more engaging. By the time you submit Lab 4.3, your game is fully data-driven. Every major piece of data lives in a dictionary, input is clean, tracking is automatic, and the gate has skill. That's a professional-level architecture."

### Key Terms
- **MASTER week** — The third week of each module; you copy your previous lab file, rename it `lab-4-3.py`, and integrate everything you've learned across the full module
- **Data-driven** — Program behavior is controlled by data structures rather than hardcoded logic; adding a new city or question is a data entry, not a code change

### Discussion Questions
1. Think back to Module 1. How many separate places in the code did you have to change to add or modify a city? How many places does it take now?
2. Why is replacing a coin flip with a trivia question a better design — not just for fun, but for code architecture?

---

## Slide 3: Sets — Quick Review Before We Go Deeper

### Key Points
1. A **set** stores unique, unordered elements — duplicates are automatically discarded.
2. Create a set with curly braces `{1, 2, 3}` or `set([list])` — but **not** `{}` alone (that creates an empty dict).
3. Add items with `.add(item)` — if the item is already there, nothing happens.
4. Use `in` to test membership, same as with lists and dicts.
5. Iterating a set works fine with `for` — but order is not guaranteed.

### Instructor Script
"Let's make sure sets are solid before we plug them into the game. The core idea: a set is like a list, but it can never hold the same value twice. You can keep calling `.add('Houston')` a hundred times — the set will still only have Houston once. That's the whole superpower. You don't check, you don't filter, you don't write an if-statement — it just works automatically. The thing to watch for is the empty set gotcha. If you write `visited = {}`, Python makes a dictionary, not a set. To get an empty set, you write `visited = set()`. That's one of the most common bugs in Chapter 9, so watch out for it in CodeGrade."

### Key Terms
- **Set** — A Python collection that stores only unique, unordered values; no element can appear more than once
- **`.add(item)`** — The method used to insert an element into a set; safe to call even if the item already exists
- **`set()`** — How you create an *empty* set; `{}` creates an empty dict instead

### Discussion Questions
1. What's the difference between a list and a set in terms of how you'd use them to track cities?
2. Why is it important that adding a duplicate to a set does nothing, rather than raising an error?

---

## Slide 4: Sets for Unique Tracking — The Before/After

### Key Points
1. In Module 3, tracking unique cities required a manual `if city not in unique_cities` check inside a loop.
2. With sets, you just call `.add(city)` every turn — the set handles the deduplication automatically.
3. Initialize both tracking sets at the top of your game: `unique_cities_visited = set()` and `unique_hazards_faced = set()`.
4. In the game loop: `unique_cities_visited.add(current_city)` — that's the entire update.
5. For the report: `sorted(unique_cities_visited)` works perfectly — `sorted()` accepts any iterable, including sets.

### Instructor Script
"Here's the side-by-side that really drives this home. In Module 3, to track unique cities you had to write a loop, check if the city was already in your list, and only append if it wasn't. That's five or six lines of code to do one logical thing. In Module 4, you replace all of that with one line: `unique_cities_visited.add(current_city)`. Call it every turn, forever, and the set just keeps track for you. Then when you want to print the report, you call `sorted()` on the set. A lot of students are surprised that `sorted()` works on a set — it does, because `sorted()` accepts any iterable, and a set is an iterable. The sorted list you get back is in alphabetical order, which is exactly what you want for a clean trip report."

### Key Terms
- **`sorted(iterable)`** — Returns a new sorted list from any iterable, including sets; does not modify the original
- **Iterable** — Any Python object that can be looped over with `for`; lists, sets, dictionaries, and strings are all iterables

### Discussion Questions
1. If you called `unique_cities_visited.add('Houston')` fifty times during a game, how many times would Houston appear in the final report?
2. Why does it matter that `sorted()` returns a *list* rather than modifying the set in place?

---

## Slide 5: DEMO — Sets in Action

> **Code PNG:** `slide05_sets_tracking.png`
> **Output PNG:** `slide05b_sets_tracking_output.png`

```python
# Sets for unique tracking
unique_cities_visited = set()
unique_hazards_faced = set()

# Simulate a few turns
unique_cities_visited.add('San Antonio')
unique_cities_visited.add('Houston')
unique_cities_visited.add('Houston')   # duplicate!
unique_cities_visited.add('Dallas')
unique_cities_visited.add('San Antonio')  # duplicate!

unique_hazards_faced.add('flat tire')
unique_hazards_faced.add('dust storm')
unique_hazards_faced.add('flat tire')   # duplicate!

# Report
print(f'Unique cities: {len(unique_cities_visited)}')
for city in sorted(unique_cities_visited):
    print(f'   - {city}')

print(f'Unique hazards: {len(unique_hazards_faced)}')
for h in sorted(unique_hazards_faced):
    print(f'   - {h}')
```

**Expected Output:**
```
Unique cities: 3
   - Dallas
   - Houston
   - San Antonio
Unique hazards: 2
   - dust storm
   - flat tire
```

### Instructor Notes
Point out: we added Houston twice and San Antonio twice, but both appear only once. The set discarded the duplicates silently. `sorted()` returns alphabetical order automatically. This is what replaces the Module 3 duplicate-check loop.

---

## Slide 6: The TRIVIA Dictionary — Structure

### Key Points
1. `TRIVIA` is a dictionary where each **key is a city name** and each **value is a list of question dictionaries**.
2. Each question dictionary has two keys: `'question'` (the text) and `'answer'` (`'TRUE'` or `'FALSE'`).
3. Having a list of questions per city means `random.choice()` picks a different question each time.
4. Use `.get(city, TRIVIA['San Antonio'])` as a safe fallback — if a city doesn't have trivia, default to San Antonio's questions.
5. This is a dictionary of lists of dictionaries — nesting multiple data structures together is very common in real applications.

### Instructor Script
"Let's look at the TRIVIA structure, because it's the most complex dictionary you've built all semester. The outer dictionary's keys are city names — Houston, Dallas, Austin, and so on. The value for each city is a *list* of question dictionaries. So you've got a dict containing a list containing dicts. That might sound intimidating, but just think about what you're modeling: a city has multiple possible questions. A list is the right tool for 'multiple of something.' And each question needs two pieces of data — the question text and the correct answer. A dictionary is the right tool for 'named pieces of data that go together.' This is how real-world data gets structured. You've been building toward this all semester."

### Key Terms
- **Nested data structure** — A data structure that contains other data structures as its values; `TRIVIA` is a dict of lists of dicts
- **`random.choice(list)`** — Returns a random element from a list; used here to pick a random trivia question for the chosen city

### Discussion Questions
1. Why store a *list* of questions per city instead of just one question per city?
2. What would you need to change in the TRIVIA dictionary to add a brand-new city? How much of the rest of your code would need to change?

---

## Slide 7: DEMO — The TRIVIA Dictionary

> **Code PNG:** `slide07_trivia_dict.png`
> **Output PNG:** `slide07b_trivia_dict_output.png`

```python
import random

TRIVIA = {
    'Austin': [
        {'question': 'Austin is the capital of Texas.',
         'answer': 'TRUE'},
        {'question': 'Austin is known as the Live Music Capital.',
         'answer': 'TRUE'},
    ],
    'Houston': [
        {'question': 'Houston is the largest city in Texas.',
         'answer': 'TRUE'},
        {'question': 'Houston is on the Texas coast.',
         'answer': 'FALSE'},
    ],
}

city = 'Austin'
questions = TRIVIA.get(city, TRIVIA['Austin'])
q = random.choice(questions)
print(f'City: {city}')
print(f'Q: {q["question"]}')
print(f'Answer: {q["answer"]}')
```

**Expected Output (one possible run):**
```
City: Austin
Q: Austin is the capital of Texas.
Answer: TRUE
```

### Instructor Notes
Show the nested access pattern: `q["question"]` and `q["answer"]`. Point out `.get()` with a default — the safe lookup pattern they already know from Lab 4.2, now applied to TRIVIA. Note that the output will vary because `random.choice()` picks from multiple questions.

---

## Slide 8: The Trivia Gate — Replacing the Coin Flip

### Key Points
1. The Destination Gate used to call `flip_coin()` — pure luck, no player skill involved.
2. The new `trivia_gate(destination)` function **returns True** (correct) or **False** (wrong).
3. If the player answers correctly, they get their chosen destination; if wrong, they get a random redirect.
4. The function uses `clean_input()` to normalize the answer — `'true'`, `'TRUE'`, `'t'`, and `'T'` all work.
5. Track two new counters: `trivia_asked` (increments every gate) and `trivia_correct` (increments only on correct answers).

### Instructor Script
"Here's the design of the trivia gate. It's a function — `trivia_gate(destination)` — that takes the city the player chose, asks them a question about it, and returns True or False based on whether they got it right. The caller — your main game loop — uses that return value to decide what happens: correct gets the chosen city, wrong gets a random redirect. This is a really clean design pattern. The gate function doesn't know anything about the rest of the game. It just asks, evaluates, and returns. That separation of concerns is exactly what we've been building toward with functions all semester. Also notice: we're still using `clean_input()` from Lab 4.1. Your function library earns its keep again."

### Key Terms
- **`trivia_gate(destination)`** — A function that asks a trivia question about the target city and returns `True` (correct) or `False` (wrong)
- **Return value** — The value a function sends back to its caller; here, `True`/`False` controls which city the player ends up in
- **Separation of concerns** — A design principle where each function is responsible for one clearly defined task; the gate doesn't know about the rest of the game

### Discussion Questions
1. Why is it better design to have `trivia_gate()` return a boolean rather than printing the result and deciding the destination inside the function?
2. What are the two counters you need to track, and where in the code should each one be incremented?

---

## Slide 9: DEMO — The Trivia Gate Function

> **Code PNG:** `slide09_trivia_gate.png`
> **Output PNG:** `slide09b_trivia_gate_output.png`

```python
def trivia_gate(destination):
    """Ask trivia about destination. Returns True if correct."""
    city_trivia = TRIVIA.get(destination, TRIVIA['San Antonio'])
    question_data = random.choice(city_trivia)
    question = question_data['question']
    correct = question_data['answer']

    print()
    print('  TRIVIA TIME!')
    print(f'  About {destination}:')
    print(f'  "{question}"')
    print('  Is this TRUE or FALSE?')

    raw = clean_input('  Your answer: ')
    if raw in ['T', 'TRUE']:
        player_answer = 'TRUE'
    elif raw in ['F', 'FALSE']:
        player_answer = 'FALSE'
    else:
        print('  Invalid! Treating as FALSE.')
        player_answer = 'FALSE'

    if player_answer == correct:
        print('  CORRECT! You earned your destination!')
        return True
    else:
        print(f'  WRONG! Answer was {correct}.')
        print('  Texas has other plans...')
        return False
```

**Example Output (wrong answer):**
```
  TRIVIA TIME!
  About Houston:
  "Houston is on the Texas coast."
  Is this TRUE or FALSE?
  Your answer: TRUE
  WRONG! Answer was FALSE.
  Texas has other plans...
```

### Instructor Notes
Max 13 lines — this splits across two PNGs. First PNG is the function definition (lines 1–13). Second is the continuation (lines 14–end). The `_cont` slide starts with `# (continued)` per spec.

---

## Slide 10: DEMO — Trivia Gate in the Main Game Loop

> **Code PNG:** `slide10_trivia_loop.png`
> **Output PNG:** `slide10b_trivia_loop_output.png`

```python
# DESTINATION GATE — now with TRIVIA!
trivia_asked += 1

if trivia_gate(destination):
    # Correct — player earns their choice
    final_dest = destination
    trivia_correct += 1
else:
    # Wrong — random redirect
    options = list(CITY_DISTANCES[current_city].keys())
    options.remove(destination)
    final_dest = random.choice(options)
    print(f'You are heading to {final_dest} instead!')

distance = CITY_DISTANCES[current_city][final_dest]
current_city = final_dest
visited_cities.append(current_city)
unique_cities_visited.add(current_city)
total_trip_miles += distance
```

**Expected Output (wrong answer path):**
```
You are heading to Dallas instead!
```

### Instructor Notes
Emphasize two things: (1) `trivia_asked` increments *before* calling the gate — you're tracking attempts, not just wins. (2) `unique_cities_visited.add(current_city)` is here, in the main loop, right where you update the city. That's the natural place for it.

---

## Slide 11: DEMO — Final Report with Sets and Trivia Stats

> **Code PNG:** `slide11_final_report.png`
> **Output PNG:** `slide11b_final_report_output.png`

```python
print('=' * 50)
print('FINAL TRIP REPORT')
print('=' * 50)
print()
print('YOUR ROUTE:')
print('  ' + ' -> '.join(visited_cities))
print()
print(f'Unique cities visited: {len(unique_cities_visited)}')
for city in sorted(unique_cities_visited):
    print(f'  - {city}')
print()
print(f'Unique hazards faced: {len(unique_hazards_faced)}')
for h in sorted(unique_hazards_faced):
    print(f'  - {h}')
print()
print('TRIVIA PERFORMANCE:')
print(f'  Asked:   {trivia_asked}')
print(f'  Correct: {trivia_correct}')
if trivia_asked > 0:
    pct = (trivia_correct / trivia_asked) * 100
    print(f'  Rate:    {pct:.1f}%')
print('=' * 50)
```

**Expected Output:**
```
==================================================
FINAL TRIP REPORT
==================================================

YOUR ROUTE:
  San Antonio -> Houston -> Dallas -> Houston

Unique cities visited: 3
  - Dallas
  - Houston
  - San Antonio

Unique hazards faced: 2
  - dust storm
  - flat tire

TRIVIA PERFORMANCE:
  Asked:   3
  Correct: 2
  Rate:    66.7%
==================================================
```

### Instructor Notes
Two PNGs: code and output. The route shows Houston twice (with duplicates, showing the path), while the unique cities section shows Houston only once. That contrast is the whole point — make sure to call it out when presenting. The trivia accuracy calculation uses the familiar pattern: `(correct / asked) * 100`.

---

## Slide 12: MASTER Week — What You're Integrating

### Key Points
1. Lab 4.3 is not about learning new syntax — it's about **integrating** everything Module 4 taught you.
2. Copy your `lab-4-2.py` and rename it `lab-4-3.py` before writing a single new line.
3. Three additions: `TRIVIA` dictionary, trivia gate function replacing coin flip, and two tracking sets.
4. The final report gains two new sections: unique city/hazard lists (from sets) and trivia performance stats.
5. Scope compliance still applies — your CodeGrade submission will be checked; sets and `TRIVIA` must be present.

### Instructor Script
"MASTER week has a different energy than BUILD or ENHANCE weeks. You're not learning a new concept from scratch — you're proving you can put it all together. The three additions are very specific. You need the TRIVIA dictionary built out with questions for your cities. You need a `trivia_gate()` function that replaces the coin flip. And you need two sets — `unique_cities_visited` and `unique_hazards_faced` — that you `.add()` to during the game loop and report on at the end. If any of those three things are missing, CodeGrade will flag it. But more importantly: when this is done, you have a genuinely well-designed game. Everything data-driven. Input clean. Tracking automatic. Gate skill-based. That's not just a homework assignment — that's a real program."

### Key Terms
- **Integration** — Combining multiple concepts and techniques from across a module into a single working program
- **Scope compliance** — The CodeGrade check that verifies you used the required techniques (sets, TRIVIA, trivia gate) for this assignment

### Discussion Questions
1. Which of the three additions — TRIVIA dictionary, trivia gate, or sets — do you think will take the longest to implement? Why?
2. What would you test first to make sure the trivia gate is working correctly before submitting to CodeGrade?

---

## Slide 13: Solution Quality Grading — What Instructors Look For

### Key Points
1. Lab 4.3 is a MASTER assignment — it gets **Solution Quality** grading in addition to automated tests.
2. Logic approach: Is the trivia gate a clean function, or is the logic scattered through the main loop?
3. Edge case awareness: What happens when `trivia_asked` is 0 at the end — does the division still work?
4. Code organization: Are all three new additions (TRIVIA, gate, sets) cleanly placed and easy to find?
5. Documentation quality: Does the `trivia_gate()` docstring actually describe what it takes, returns, and does?

### Instructor Script
"I want to take a minute on Solution Quality because this is a MASTER week. Automated grading catches whether your code runs correctly. Solution Quality is me reading your code and evaluating whether your *approach* is sound. The three things I'm specifically looking at this week: Is `trivia_gate()` a proper function, or did you just copy the logic inline into your main loop? Did you guard the accuracy calculation against division by zero — what if trivia_asked is zero? And are your docstrings actually useful? A docstring that says 'this function asks trivia' is not the same as one that says 'takes a destination city string, returns True if the player answers correctly, False otherwise.' The second one tells me you understand what your function does."

### Key Terms
- **Solution Quality** — The manually graded component of MASTER assignments; evaluates logic approach, edge case handling, organization, and documentation quality
- **Guard clause** — A condition placed before a potentially dangerous operation; `if trivia_asked > 0:` before the accuracy division is a guard against division by zero

### Discussion Questions
1. Why is `if trivia_asked > 0:` before the accuracy calculation important? What error would you get without it?
2. What's the difference between a docstring that describes *what* a function does versus *how* it works — and which one is more useful?

---

## Slide 14: Lab 4.3 Walkthrough — The Three Changes

### Key Points
1. **Step 1: Add TRIVIA** — Build the `TRIVIA` dictionary with at least one question per city in your game.
2. **Step 2: Replace the coin flip** — Write `trivia_gate(destination)`, then swap it in wherever the Destination Gate appears.
3. **Step 3: Add sets** — Initialize `unique_cities_visited = set()` and `unique_hazards_faced = set()` at the top; `.add()` during the loop; report at the end.
4. Test the gate alone first by calling it with a hardcoded city before plugging it into the main game.
5. Submit to CodeGrade early — the trivia flow is complex enough that automated tests will catch edge cases you might miss.

### Instructor Script
"Here's the practical approach. Start with TRIVIA. Write the dictionary, get all your cities covered, test that you can access a random question with `random.choice(TRIVIA['Houston'])`. Once the data is right, write `trivia_gate()`. Test it standalone — call it from the bottom of your file with a hardcoded city, verify it prints correctly, verify it returns True and False correctly. THEN plug it into the Destination Gate, replacing the coin flip. After that, add the sets. They're actually the easiest part. Two initializations at the top, two `.add()` calls in the loop, two report sections at the bottom. That's it. Submit early. The CodeGrade tests for MASTER week are the most complex of the semester."

### Key Terms
- **Standalone test** — Running a specific function in isolation before integrating it into the main program; helps catch bugs before they interact with other code

### Discussion Questions
1. Why is it a good idea to test `trivia_gate()` with a hardcoded city *before* connecting it to the game loop?
2. What would the output look like if your sets were working but `sorted()` was missing — what would change?

---

## Slide 15: This Week's Action Items

### Key Points
1. **Copy** your `lab-4-2.py` and rename it `lab-4-3.py` — do this first, before anything else.
2. Build the `TRIVIA` dictionary, write `trivia_gate()`, and connect the gate — that's the core work.
3. Add `unique_cities_visited` and `unique_hazards_faced` sets throughout your game.
4. Upgrade the final report with unique city/hazard lists and trivia accuracy stats.
5. Zoom is Tuesday at 6 PM — come with your `trivia_gate()` working and questions about the integration.

### Instructor Script
"Here's what your week looks like. Monday or Tuesday, copy the file and rename it. Wednesday, build out TRIVIA and get the trivia gate working standalone. Thursday or Friday, plug the gate into the main game and add the sets. Weekend, clean everything up, add docstrings, check your Flake8, and submit. The Zoom session Tuesday is specifically useful this week because the trivia integration has more moving parts than anything we've done before. Bring whatever you've got — even a partially working gate — and we'll work through it together."

### Key Terms
- **Flake8** — The automated code style checker in CodeGrade; make sure all lines are under 80 characters and formatting is clean before final submission

### Discussion Questions
1. What's your plan for this week — which of the three additions will you tackle first and why?
2. What's the best way to verify that your sets are working correctly before you submit?

---

# APPENDIX A — Demo Slide PNG Index

Each demo slide uses one code PNG and one output PNG. These are the files your PNG renderer will produce. Drop them into your Keynote deck in the slots listed.

| Slide | Code PNG | Output PNG | Topic |
|-------|----------|------------|-------|
| 5 | `slide05_sets_tracking.png` | `slide05b_sets_tracking_output.png` | Sets + `.add()` + `sorted()` tracking |
| 7 | `slide07_trivia_dict.png` | `slide07b_trivia_dict_output.png` | TRIVIA dictionary structure |
| 9 | `slide09_trivia_gate.png` | `slide09b_trivia_gate_output.png` | `trivia_gate()` function definition |
| 9c | `slide09c_trivia_gate_cont.png` | — | Gate function continued (split at line 13) |
| 10 | `slide10_trivia_loop.png` | `slide10b_trivia_loop_output.png` | Trivia gate in main game loop |
| 11 | `slide11_final_report.png` | `slide11b_final_report_output.png` | Final report with sets + trivia stats |

---

# APPENDIX B — Key Terms Master List (Week 12)

| Term | Definition |
|------|------------|
| **Set** | A Python collection storing only unique, unordered values; no duplicates allowed |
| **`.add(item)`** | Inserts an element into a set; safe to call even if the element already exists |
| **`set()`** | Creates an empty set; `{}` creates an empty dict instead — this is a common bug |
| **`sorted(iterable)`** | Returns a new sorted list from any iterable, including sets |
| **Iterable** | Any Python object that can be looped over with `for`; lists, sets, dicts, and strings qualify |
| **TRIVIA** | The dictionary of city trivia questions; keys are city names, values are lists of question dicts |
| **`trivia_gate(destination)`** | Function that asks a trivia question and returns `True` (correct) or `False` (wrong) |
| **Nested data structure** | A data structure whose values contain other data structures; e.g., a dict of lists of dicts |
| **`random.choice(list)`** | Returns a randomly selected element from a list |
| **Return value** | The value a function sends back to its caller; `trivia_gate()` returns a boolean |
| **Separation of concerns** | Design principle: each function does one clearly defined thing |
| **Guard clause** | A condition that prevents a dangerous operation; `if trivia_asked > 0:` guards division |
| **Solution Quality** | Manually graded component of MASTER assignments; evaluates approach and documentation |
| **Scope compliance** | CodeGrade check verifying required techniques (sets, TRIVIA) are present |
| **Standalone test** | Running a function in isolation before integrating it into the larger program |
| **Data-driven** | Program behavior controlled by data structures, not hardcoded logic |

---

# APPENDIX C — Module 4 Complete Picture

By the end of Lab 4.3, here is what students will have built:

| Feature | Where It Lives | Module 4 Week |
|---------|---------------|---------------|
| `.upper()` / `.strip()` input cleaning | `function_library.py` | Week 10 (BUILD) |
| `clean_input()` / `clean_input_lower()` | `function_library.py` | Week 10 (BUILD) |
| `CITY_DISTANCES` nested dict | `lab-4-3.py` constants | Week 11 (ENHANCE) |
| `CITY_INFO` dict | `lab-4-3.py` constants | Week 11 (ENHANCE) |
| `HAZARDS` dict | `lab-4-3.py` constants | Week 11 (ENHANCE) |
| `TRIVIA` dict | `lab-4-3.py` constants | Week 12 (MASTER) |
| `trivia_gate()` function | `lab-4-3.py` | Week 12 (MASTER) |
| `unique_cities_visited` set | `lab-4-3.py` game state | Week 12 (MASTER) |
| `unique_hazards_faced` set | `lab-4-3.py` game state | Week 12 (MASTER) |
| Trivia stats in final report | `lab-4-3.py` report | Week 12 (MASTER) |

**Module 5 Preview:** All of this data — TRIVIA, CITY_DISTANCES, CITY_INFO, HAZARDS — will become the *attributes* of City and Game objects. The same game, rebuilt with classes.

---

**Document created:** March 2026
**Status:** READY FOR KEYNOTE
