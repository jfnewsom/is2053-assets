"""
Programming Exercise 4-2
"""


def main():
    """
    This is the main function, where the primary code
    for your program will reside.  Note that everything
    inside of the main 'code block' is indented.

    """
    # Declare a variable to store the increase amount, tuition and total.
    increase = 0.066
    tuition = 10966.0
    total = 0.0

    # Calculate and print amount of increase each year.
    print('\nYear #\t\tProjected Annual Tuition')
    print('------------------------------------------')

    for year in range(1, 5):
        tuition += (tuition * increase)
        total += tuition
        print(f'{year:6}\t\t${tuition:,.2f}')

    print('------------------------------------------')
    print(f'The total 4-year cost is: ${total:,.2f}\n')


# Call the main function.
if __name__ == '__main__':
    main()
