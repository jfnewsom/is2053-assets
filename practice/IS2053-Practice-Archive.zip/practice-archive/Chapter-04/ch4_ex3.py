"""
Programming Exercise 4-3
"""


def main():
    """
    This is the main function, where the primary code
    for your program will reside.  Note that everything
    inside of the main 'code block' is indented.
    """

    # Inititalize number to zero.
    number = 0
    fact_str = ''
    # Get a valid number from the user.
    while number <= 0:
        number = int(input('\nEnter a nonnegative integer: '))

    # Initialize the accumulator variable.
    factoral = 1

    # Calculate the factoral of the number.
    for factor in range(1, number + 1):
        factoral *= factor
        if factor < number:
            fact_str = fact_str + f'{factor} \u02df '
        else:
            fact_str = fact_str + f'{factor}'

    # Display the factoral of the number.
    print(f'\nThe factorial of {number} is:')
    print(f'{number}! = {fact_str} = {factoral:,d}\n')


# Call the main function.
if __name__ == '__main__':
    main()
