"""
Programming Exercise 4-1
"""


def main():
    """
    This is the main function, where the primary code
    for your program will reside.  Note that everything
    inside of the main 'code block' is indented.
    """
    # Declare variables for the number, and the
    # total.
    number = 1.0    # Initialize for while loop
    total = 0.0
    print('\nThis program allows the user to enter limitless')
    print('positive numbers and receive the sum of those ')
    print('numbers once a negative number is entered.\n')

    # Continue adding numbers while they are positive.
    while number > 0:
        number = float(input('Enter a positive number (negative to quit): '))
        if number > 0:
            total = total + number

    # Display total.
    print(f'\nTotal = {total:.10f}\n')


# Call the main function.
if __name__ == '__main__':
    main()
