'''
Programming Exercise 11-1
'''
import emp


def main():
    '''Local variables'''
    prodworker_list = []
    supervisor_list = []

    # Instantiate Objects
    prodworker_list.append(emp.ProductionWorker('Frank McMullen',
                                                1001, 1, 25))
    prodworker_list.append(emp.ProductionWorker('Harriet Walter',
                                                1002, 2, 22.5))
    prodworker_list.append(emp.ProductionWorker('Tom Walton',
                                                1015, 3, 19.5))
    prodworker_list.append(emp.ProductionWorker('Mark Camacho',
                                                1027, 1, 18.5))
    prodworker_list.append(emp.ProductionWorker('Pauline Golden',
                                                1029, 3, 20.5))

    supervisor_list.append(emp.ShiftSupervisor('Ellen Duffy',
                                               2010, 40000, 800))
    supervisor_list.append(emp.ShiftSupervisor('Rick Gonzalez',
                                               2020, 39000, 750))
    supervisor_list.append(emp.ShiftSupervisor('Calvin Stafford',
                                               2022, 42000, 500))
    supervisor_list.append(emp.ShiftSupervisor('Lindsey Newman',
                                               2027, 46000, 900))
    supervisor_list.append(emp.ShiftSupervisor('Marta Salazar',
                                               2031, 48000, 1000))

    # Print each list
    print('\nProduction worker information:')
    print('==============================\n')
    for worker in range(len(prodworker_list)):
        print(f'Name: {prodworker_list[worker].get_name()}')
        print(f'ID number: {prodworker_list[worker].get_id_number()}')
        print(f'Shift: {prodworker_list[worker].get_shift_number()}')
        print('Hourly Pay Rate: '
              f'${prodworker_list[worker].get_pay_rate():,.2f}\n')

    print('\nShift Supervisor information:')
    print('===============================\n')
    for supes in range(len(supervisor_list)):
        print(f'Name: {supervisor_list[supes].get_name()}')
        print(f'ID number: {supervisor_list[supes].get_id_number()}')
        print(f'Annual Salary: ${supervisor_list[supes].get_salary():,.2f}')
        print('Annual Production Bonus: '
              f'${supervisor_list[supes].get_bonus():,.2f}\n')


# Call the main function.
if __name__ == '__main__':
    main()
