'''
CH11 emp Class
'''


class Employee:
    '''
    Employee Class
    '''
    def __init__(self, name, id_number):
        '''Initializer'''
        self.__name = name
        self.__id_number = id_number

    def set_name(self, name):
        '''Set Name'''
        self.__name = name

    def set_id_number(self, id_number):
        '''Set ID'''
        self.__id_number = id_number

    def get_name(self):
        '''Get Name'''
        return self.__name

    def get_id_number(self):
        '''Get ID'''
        return self.__id_number


class ProductionWorker(Employee):
    '''Production Worker Sub-Class'''
    def __init__(self, name, id_number, shift_number, pay_rate):
        # Call superclass __init__ method.
        Employee.__init__(self, name, id_number)

        # Initialize the shift_number and pay_rate attributes.
        self.__shift_number = shift_number
        self.__pay_rate = pay_rate

    # Mutator functions for shift_number and pay_rate.
    def set_shift_number(self, shift_number):
        '''Set Shift Number'''
        self.__shift_number = shift_number

    def set_pay_rate(self, pay_rate):
        '''Set Pay Rate'''
        self.__pay_rate = pay_rate

    # Accessor functions for shift_number and pay_rate.
    def get_shift_number(self):
        '''Get Shift Number'''
        return self.__shift_number

    def get_pay_rate(self):
        '''Get Pay Rate'''
        return self.__pay_rate


class ShiftSupervisor(Employee):
    '''Shift Supervisor Sub-Class'''
    def __init__(self, name, id_number, salary, bonus):
        # Call superclass __init__ method.
        Employee.__init__(self, name, id_number)

        # Initialize the salary and bonus attributes.
        self.__salary = salary
        self.__bonus = bonus

    # Mutator functions for salary and bonus.
    def set_salary(self, salary):
        '''set salary'''
        self.__salary = salary

    def set_bonus(self, bonus):
        '''set bonus'''
        self.__bonus = bonus

    # Accessor functions for salary and bonus.
    def get_salary(self):
        '''get salary'''
        return self.__salary

    def get_bonus(self):
        '''get bonus'''
        return self.__bonus
