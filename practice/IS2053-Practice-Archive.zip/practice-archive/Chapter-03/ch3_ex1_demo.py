"""
Chapter 3 - Programming Exercise 1 Redux

"""


def main():
    """
    main function

    """
    # Get the number for the shape_numb of the week.
    shape_name = ''
    shape_numb = int(input('\nEnter a number (1-6) for the shape: '))

    # Determine the name of the shape_numb of the week, and display it.
    if shape_numb == 1:
        shape_name = 'a Circle'
    elif shape_numb == 2:
        shape_name = 'a Square'
    elif shape_numb == 3:
        shape_name = 'a Triangle'
    elif shape_numb == 4:
        shape_name = 'a Hexagon'
    elif shape_numb == 5:
        shape_name = 'an Oval'
    elif shape_numb == 6:
        shape_name = 'a Rectangle'
    else:
        shape_name = 'an error -- please enter a number between 1 and 6'

    # Print the results
    print(f'Shape #{shape_numb} is {shape_name}.\n')


# Call the main function.
if __name__ == '__main__':
    main()
