"""
Chapter 3 - Programming Exercise 1

"""


def main():
    """
    main function

    """
    # Get the number for the month_numb of the week.
    month_name = ''
    month_numb = int(input('\nEnter a number (1-12) '
                           + 'for the month of the year: '))

    # Determine the name of the month_numb of the week, and display it.
    if month_numb == 1:
        month_name = 'January'
    elif month_numb == 2:
        month_name = 'February'
    elif month_numb == 3:
        month_name = 'March'
    elif month_numb == 4:
        month_name = 'April'
    elif month_numb == 5:
        month_name = 'May'
    elif month_numb == 6:
        month_name = 'June'
    elif month_numb == 7:
        month_name = 'July'
    elif month_numb == 8:
        month_name = 'August'
    elif month_numb == 9:
        month_name = 'September'
    elif month_numb == 10:
        month_name = 'October'
    elif month_numb == 11:
        month_name = 'November'
    elif month_numb == 12:
        month_name = 'December'
    else:
        month_name = 'an error -- please enter a number between 1 and 12'

    # Print the results
    print(f'Month #{month_numb} is {month_name}.\n')


# Call the main function.
if __name__ == '__main__':
    main()
