"""
Chapter 3 - Programming Exercise 2

"""


def main():
    """
    main function

    """
    # Declare and initialize variables
    primary1 = ''
    primary2 = ''
    secondary = ''

    # Get first color from the user.
    primary1 = input('\nEnter the first primary color in lowercase letters: ')

    # Get second color from the user.
    primary2 = input('Enter the second primary color in lowercase letters: ')

    # Check validity of first color.
    if primary1 != 'red' and primary1 != 'blue' and primary1 != 'yellow':
        secondary = 'error: the first color is invalid'

    # Check validity of second color.
    elif primary2 != 'red' and primary2 != 'blue' and primary2 != 'yellow':
        secondary = 'error: the second color is invalid'

    # Check if the two colors are the same.
    elif primary1 == primary2:
        secondary = 'error: the colors are the same'

    # Display the secondary color resulting from mixing the two colors.
    else:
        # Determine secondary color if the first color is red.
        if primary1 == 'red':
            if primary2 == 'blue':
                secondary = 'purple'
            else:  # Color 2 must be yellow
                secondary = 'orange'

        # Determine secondary color if first color is blue.
        elif primary1 == 'blue':
            if primary2 == 'red':
                secondary = 'purple'
            else:  # Color 2 must be yellow.
                secondary = 'green'

        else:  # First color must be yellow.
            if primary2 == 'red':
                secondary = 'orange'
            else:  # Color 2 must be blue.
                secondary = 'green'

    # Print the results.
    print(f'\nColor Mixer Results: {primary1} + {primary2} = {secondary}.\n')


# Call the main function.
if __name__ == '__main__':
    main()
