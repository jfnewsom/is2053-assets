"""
Programming Exercise 6-2

Average of Numbers
"""


def main():
    """
    go away squigglies
    """
    # Declare variables
    total = 0.0
    number = 0.0
    counter = 0

    # Open numbers.txt file for reading
    in_file = open('6-2-numbers.txt', 'r', encoding='UTF-8')

    for line in in_file:
        counter = counter + 1
        # print(f'counter {counter}')
        number = float(line)
        total += number
        # print(f'number {number}')
        # print(f'total {total}')

    # Close file
    in_file.close()

    # Calculate average
    average = total / counter

    # Display the average of the numbers in the file
    print(f'\nTotal:\t\t{total:10,.2f}')
    print(f'# of Lines:\t{counter:10.0f}')
    print(f'Average:\t{average:10,.2f}\n')


# Call the main function.
if __name__ == '__main__':
    main()
