"""
Programming Exercise 6-3

# Exception Handing
"""


def main():
    """Declare local variables"""
    num_total = 0
    number = 0.0
    counter = 0

    file_name = input('Enter the name of the file: ')
    # file_name = '6-3-lines1.txt'
    # file_name = '6-3-lines2.txt'

    try:
        # Open file for reading
        infile = open(file_name, 'r')

        for line in infile:
            counter = counter + 1
            number = float(line)
            num_total += number

        # Close file
        infile.close()

        # Calculate average
        average = num_total / counter

        # Display the average of the numbers in the file
        print(f'\nTotal:\t\t{num_total:10,.2f}')
        print(f'# of Lines:\t{counter:10,.2f}')
        print(f'Average:\t{average:10,.2f}\n')

    except IOError:
        print('\nAn error occurred while trying to read the file.\n')
    except ValueError:
        print('\nNon-numeric data is found in the file.\n')


# Call the main function.
if __name__ == '__main__':
    main()
