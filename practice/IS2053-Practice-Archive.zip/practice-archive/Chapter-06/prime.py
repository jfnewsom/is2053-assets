import math


# A function that checks if a given number is prime
def is_prime(n):
    # If n is less than 2, it is not prime
    if n < 2:
        return False

    # Check all the possible divisors from 2 to the square root of n
    limit = int(math.sqrt(n))
    for i in range(2, limit + 1):
        # If n is divisible by i, it is not prime
        if n % i == 0:
            return False

    # If none of the divisors divided n evenly, it is prime
    return True


# Ask the user to enter a number
num = int(input("Enter a number: "))

# Check if the number is prime and print the result
result = is_prime(num)
print(f"{num} is {'prime' if result else 'not prime'}.")
