"""
 Programming Exercise 6-1

File Head Display
"""


def main():
    """
    go away squigglies
    """
    # Declare variables
    line = ''
    counter = 0

    # Prompt for file name
    file_name = input('Enter the name of the file: ')
    # file_name = '6-1-lines1.txt'
    # file_name = '6-1-lines2.txt'

    # Open the specified file for reading
    in_file = open(file_name, 'r', encoding='UTF-8')

    # Priming read
    line = in_file.readline().rstrip('\n')
    counter = 1

    # Read in and display first five lines
    while line != '' and counter <= 5:
        print(line)
        line = in_file.readline().rstrip('\n')
        # Update counter when line is read
        counter += 1

    # Close file
    in_file.close()


# Call the main function.
if __name__ == '__main__':
    main()
