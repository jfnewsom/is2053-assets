'''
Programming Exercise 10-2
'''


class Question:
    ''' grn '''
    def __init__(self, question, answer1, answer2,
                 answer3, answer4, solution):
        ''' constructor '''
        self.__question = question
        self.__answer1 = answer1
        self.__answer2 = answer2
        self.__answer3 = answer3
        self.__answer4 = answer4
        self.__solution = solution

    def set_question(self, question):
        ''' mutator for question '''
        self.__question = question

    def set_answer1(self, answer1):
        ''' mutator for answer1 '''
        self.__answer1 = answer1

    def set_answer2(self, answer2):
        ''' mutator for answer2 '''
        self.__answer2 = answer2

    def set_answer3(self, answer3):
        ''' mutator for answer3 '''
        self.__answer3 = answer3

    def set_answer4(self, answer4):
        ''' mutator for answer4 '''
        self.__answer4 = answer4

    def set_solution(self, solution):
        ''' mutator for solution '''
        self.__solution = solution

    def get_question(self):
        ''' accessor for question '''
        return self.__question

    def get_answer1(self):
        ''' accessor for answer1 '''
        return self.__answer1

    def get_answer2(self):
        ''' accessor for answer2 '''
        return self.__answer2

    def get_answer3(self):
        ''' accessor for answer3 '''
        return self.__answer3

    def get_answer4(self):
        ''' accessor for answer4 '''
        return self.__answer4

    def get_solution(self):
        ''' accessor for solution '''
        return self.__solution

    def __str__(self):
        ''' current state of item '''
        result = '\n' + self.get_question() + '\n\n' + \
                 '1. ' + self.get_answer1() + '\n' + \
                 '2. ' + self.get_answer2() + '\n' + \
                 '3. ' + self.get_answer3() + '\n' + \
                 '4. ' + self.get_answer4() + '\n'
        return result

    def is_correct(self, answer):
        ''' returns true for correct answer, otherwise false '''
        return answer == self.get_solution()
