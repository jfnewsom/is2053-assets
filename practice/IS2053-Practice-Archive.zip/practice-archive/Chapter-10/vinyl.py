'''
Programming Exercise 10-1 (vinyl.py)
'''


class VinylItem:
    '''
    Holds the data structure for the VinylItem class
    '''
    def __init__(self, artist, title, stock, price):
        ''' constructor for vinyl_item '''
        self.__artist = artist
        self.__title = title
        self.__stock = stock
        self.__price = price

    def set_artist(self, artist):
        ''' mutator for artist '''
        self.__artist = artist

    def set_title(self, title):
        ''' mutator for title '''
        self.__title = title

    def set_stock(self, stock):
        ''' mutator for stock '''
        self.__stock = stock

    def set_price(self, price):
        ''' mutator for price '''
        self.__price = price

    def get_artist(self):
        ''' accessor for artist '''
        return self.__artist

    def get_title(self):
        ''' accessor for title '''
        return self.__title

    def get_stock(self):
        ''' accessor for stock '''
        return self.__stock

    def get_price(self):
        ''' accessor for price '''
        return self.__price

    def __str__(self):
        ''' returns current state of item '''
        result = 'Artist:\t' + self.get_artist() + '\n' + \
                 'Title:\t' + self.get_title() + '\n' + \
                 'Stock:\t' + str(self.get_stock()) + \
                 '\nPrice:\t$' + str(self.get_price())
        return result
