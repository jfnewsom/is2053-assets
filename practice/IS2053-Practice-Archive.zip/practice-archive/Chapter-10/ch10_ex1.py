'''
Programming Exercise 10-1

'''
import vinyl


def main():
    '''
    Create the five instances of the vinyl_items from class vinyl
    then print them out.

    '''
    # Create five instances of VinylItem.
    item1 = vinyl.VinylItem('The Lumineers', 'Brightside', 12, 17.79)
    item2 = vinyl.VinylItem('Shakira', 'Laundry Service', 21, 16.62)
    item3 = vinyl.VinylItem('Adele', '30', 20, 39.97)
    item4 = vinyl.VinylItem('Tom Petty & the Heartbreakers', 'Greatest Hits',
                            26, 24.64)
    item5 = vinyl.VinylItem('Nirvana', 'Nevermind 30th Anniversary Edition',
                            5, 31.99)

    # Print the five instances.
    print('\nRecord Store Item 1: ')
    print(item1)
    print('\nRecord Store Item 2:')
    print(item2)
    print('\nRecord Store Item 3:')
    print(item3)
    print('\nRecord Store Item 4: ')
    print(item4)
    print('\nRecord Store Item 5: ')
    print(item5)


# Call the main function.
if __name__ == '__main__':
    main()
