"""
Programming Exercise 5-2

Football Seating

"""

# Global constants for stadium seating
SECT_112 = 203
SECT_113 = 121
SECT_116 = 28


# main module
def main():
    """
    This is the main function, where the primary code
    for your program will reside.  Note that everything
    inside of the main 'code block' is indented.

    """
    # Local variables
    cnt112seats = 0
    cnt113seats = 0
    cnt116seats = 0
    inc112seats = 0.0
    inc113seats = 0.0
    inc116seats = 0.0

    # Get A count
    cnt112seats = int(input('\nEnter the count of Section 112 seats: '))

    # Get B count
    cnt113seats = int(input('Enter the count of Section 113 seats: '))

    # Get C count
    cnt116seats = int(input('Enter the count of Section 116 seats: '))

    # Calculate income
    inc112seats = class_total(cnt112seats, 112)
    inc113seats = class_total(cnt113seats, 113)
    inc116seats = class_total(cnt116seats, 116)

    # Print income
    income(inc112seats, inc113seats, inc116seats)


def class_total(num_seats, seat_class):
    """
    The class_total returns

    """
    if seat_class == 112:
        return SECT_112 * num_seats
    elif seat_class == 113:
        return SECT_113 * num_seats
    else:
        return SECT_116 * num_seats


def income(inc112seats, inc113seats, inc116seats):
    """
    The showIncome function accepts the income from class
    A, B, and C seats and displays the total income.

    """
    # Local variable
    total_income = 0.0

    # Calculate total income
    total_income = inc112seats + inc113seats + inc116seats

    # Show results
    print(f'\nIncome from Section 112 seats:\t${inc112seats:8,.0f}')
    print(f'Income from Section 113 seats:\t${inc113seats:8,.0f}')
    print(f'Income from Section 116 seats:\t${inc116seats:8,.0f}')
    print(f'\nTotal income:\t\t\t${total_income:8,.0f}\n')


# Call the main function.
if __name__ == '__main__':
    main()
