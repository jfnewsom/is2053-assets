"""
Programming Exercise 5-3

Math Quiz

"""

import random


# main function
def main():
    """
    This is the main function, where the primary code
    for your program will reside.  Note that everything
    inside of the main 'code block' is indented.

    """
    # Local variables
    multiplicand = 0
    multiplier = 0
    correct_answer = 0
    user_answer = 0

    # Get numbers
    multiplicand = random.randint(0, 99)
    multiplier = random.randint(0, 9)

    # Display math problem
    display_problem(multiplicand, multiplier)

    # Get user answer
    user_answer = get_answer()

    # Calculate correct answer
    correct_answer = multiplicand * multiplier

    # Display result
    show_result(correct_answer, user_answer)


def display_problem(multiplicand, multiplier):
    """
    The display_problem function accepts the numbers
    and displays them

    """
    print(f'\n\t\t{multiplicand:3}')
    print(f'\t\t\u02df{multiplier:2}')
    print('\t\t---')


def get_answer():
    """
    The get_answer function gets and returns the user answer

    """
    answer_in = int(input('Enter product:  '))
    return answer_in


def show_result(correct_answer, answer):
    """
    The show_result function tells if user answer is
    correct or not

    """
    if correct_answer == answer:
        print("\nCorrect answer - Good Work!\n")
    else:
        print(f"\nIncorrect. The correct answer is: {correct_answer}\n")


# Call the main function.
if __name__ == '__main__':
    main()
