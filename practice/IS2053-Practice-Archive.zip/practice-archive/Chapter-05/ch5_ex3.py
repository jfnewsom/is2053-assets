"""
Programming Exercise 5-4

Test average and grade
"""


# main function
def main():
    """
    This is the main function, where the primary code
    for your program will reside.  Note that everything
    inside of the main 'code block' is indented.

    """
    # Local variables
    average = 0.0
    score1 = 0.0
    score2 = 0.0
    score3 = 0.0

    # Get scores
    score1 = float(input("\nEnter Exam 1 score: "))
    score2 = float(input("Enter Exam 2 score: "))
    score3 = float(input("Enter Exam 3 score: "))

    # Calculate average grade
    average = calc_average(score1, score2, score3)

    # Display grade and average information in tabular form
    print("\nScore\t\tNumeric Grade\tLetter Grade")
    print("----------------------------------------------------")
    print(f"Exam 1:\t\t{score1:5.1f}\t\t{determine_grade(score1)}")
    print(f"Exam 2:\t\t{score2:5.1f}\t\t{determine_grade(score2)}")
    print(f"Exam 3:\t\t{score3:5.1f}\t\t{determine_grade(score3)}")
    print(f"Average:\t{average:5.1f}\t\t{determine_grade(average)}\n")


def calc_average(test_1, test_2, test_3):
    """
    The calc_average function returns average of 3 grades
    """
    calc = (test_1 + test_2 + test_3) / 3.0
    return calc


def determine_grade(score):
    """
    The determine_grade function receives a numeric
    grade and returns the corresponding letter grade

    """
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"


# Call the main function.
if __name__ == '__main__':
    main()
