===============================================
IS2053 PRACTICE ARCHIVE
Extra Practice Problems with Solutions
===============================================

These are RETIRED programming exercises from a previous semester.
They cover the same concepts as your current assignments but with
different problems. Use them for extra practice!

HOW TO USE THIS ARCHIVE
-----------------------
1. Open the assignment sheet (.docx) for the chapter you want to practice
2. Read the problem description and requirements
3. TRY TO SOLVE IT YOURSELF FIRST (this is the important part!)
4. Compare your solution to the provided .py files
5. If stuck, peek at the solution for hints, then try again

WHAT'S INCLUDED
---------------
Chapter-02: Input, calculations, f-strings, constants
Chapter-03: if-elif-else, comparisons
Chapter-04: while loops, accumulators, sentinel values
Chapter-05: Functions, random module, math module
Chapter-06: File I/O, reading and writing text files
Chapter-07: Lists, list processing
Chapter-08: String manipulation, text processing
Chapter-09: Dictionaries, sets
Chapter-10: Classes and objects
Chapter-11: Inheritance

SUPPORT FILES
-------------
Some exercises require data files (.txt). These are included in
the relevant chapter folders.

IMPORTANT NOTES
---------------
- These exercises use ONLY techniques from chapters up to that point
- The solutions follow the same coding standards as your current labs
- Practice the PROCESS, not just getting the answer
- If you can solve these without looking at solutions, you're ready
  for the graded assignments

RECOMMENDED APPROACH
--------------------
1. Pick a chapter where you feel weak
2. Set a timer for 30-45 minutes
3. Work the problem without looking at the solution
4. When time's up (or you're done), compare to the solution
5. Note what you missed and try another problem

Questions? Come to Zoom on Tuesdays at 6 PM or post on Discord.

- Professor Newsom
