"""
Programming Exercise 9-1

"""

import random

def main():
    """
    Main function

    """
    # Initialize dictionary
    dict_counties = {'Atascosa':'Jourdanton',
                'Bandera':'Bandera',
                'Bastrop':'Bastrop',
                'Bexar':'San Antonio',
                'Caldwell':'Lockhart',
                'Comal':'New Braunfels',
                'Guadalupe':'Seguin',
                'Hays':'San Marcos',
                'Kendall':'Boerne',
                'Medina':'Hondo',
                'Travis':'Austin',
                'Williamson':'Georgetown',
                'Wilson':'Floresville'}

    # Local variables
    correct = 0
    wrong = 0
    next_question = True
    index = 0
    cnty_curr = ''
    user_input = ''


    # Continue until user quits the game.
    while next_question:

        # Get a random county name for the question.
        index = (random.randint(0,len(dict_counties)-1))
        cnty_curr = list(dict_counties)[index]

        # Get user solution.
        user_input = input(f'\nWhat is the county seat of {cnty_curr} County? (Enter 0 to quit): ')
        # User wants to quit the game.
        if user_input == '0':
            next_question = False
            print(f'\nYou had {correct} correct {plurals(correct)} and '
                  f'{wrong} incorrect {plurals(wrong)}.\n')
        # User solution is correct.
        elif user_input == dict_counties[cnty_curr]:
            correct += 1
            print('That is correct.')
        # User solution is incorrect.
        else:
            wrong += 1
            print('That is incorrect.')

def plurals(count):
    """
    The plurals function exists to return response if less than two
    else responses
    """
    if count < 2:
        return 'response'
    else:
        return 'responses'

# Call the main function.
if __name__ == '__main__':
    main()
