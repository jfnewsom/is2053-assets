word_list = ['ranch', 'cheese', 'bacon']
print('Unsorted List:')
print(word_list)
print('\nSorted List:')
print(sorted(word_list))
