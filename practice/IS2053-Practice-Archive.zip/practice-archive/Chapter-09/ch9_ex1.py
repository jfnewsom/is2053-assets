"""
Programming Exercise 9-1

"""


def main():
    """
    Main function

    """
    # Initialize dictionary
    dict_counties = {'Atascosa': 'Jourdanton',
                     'Bandera': 'Bandera',
                     'Bastrop': 'Bastrop',
                     'Bexar': 'San Antonio',
                     'Caldwell': 'Lockhart',
                     'Comal': 'New Braunfels',
                     'Guadalupe': 'Seguin',
                     'Hays': 'San Marcos',
                     'Kendall': 'Boerne',
                     'Medina': 'Hondo',
                     'Travis': 'Austin',
                     'Williamson': 'Georgetown',
                     'Wilson': 'Floresville'}

    # Local variables
    correct = 0
    wrong = 0
    user_input = ''

    # Loop through counties for test
    for county in dict_counties:
        # Get user solution.
        user_input = input(f'\nWhat is the county seat of {county} County? ')
        if user_input.lower() == dict_counties[county].lower():
            correct += 1
            print('That is correct.')
        else:
            wrong += 1
            print('That is incorrect.')

    print(f'\nYou had {correct} correct {plurals(correct)} and '
          f'{wrong} incorrect {plurals(wrong)}.\n')


def plurals(count):
    """
    The plurals function exists to return response if less than two
    else responses
    """
    if count < 2:
        return 'response'
    else:
        return 'responses'


# Call the main function.
if __name__ == '__main__':
    main()
