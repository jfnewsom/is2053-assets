"""
Programming Exercise 7-2
"""


def main():
    """
    main function
    """
    # Local variables
    test_acct = ''

    try:
        # Open the file for reading
        infile = open('7-2-accounts.txt', 'r', encoding='UTF-8')

        # Read all the lines in the file into a list
        accounts = infile.readlines()

        # Strip trailing '\n' from all elements of the list
        for iteration in range(len(accounts)):
            accounts[iteration] = accounts[iteration].rstrip('\n')
        # Get user input
        test_acct = input('\nEnter the account number to be validated: ')

        infile.close()

        # Use in operator to search for the account specified by user
        if test_acct in accounts:
            print(f'Account number {test_acct} is valid.\n')
        else:
            print(f'Account number {test_acct} is not valid.\n')
    except IOError:
        print('The file could not be found')


# Call the main function.
if __name__ == '__main__':
    main()
