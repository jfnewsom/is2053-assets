"""
Programming Exercise 7-1

Number Analysis Program (adapted from #4) - Save the file as ch7_ex1.py
Design a program that loads a text file containing a series of numbers,
then presents information about the numbers in the list.

Your program must:
•	Declare a variable named num_list and initialize it as an empty list
•	Include a function named read_file that accepts a file path and returns
    a list of numbers.
    This function will:
    o	Include a try block that will handle IOError exceptions.
    o	Use the file path argument, open the text file for reading.
    o	Read all the lines from the open file.
    o	Close the file.
    o	Strip the trailing '\n' from each line and convert the string to
        an integer.
        Hint: All the list elements must be an int for the math
        functions to work.
    o	Return the list of integers read from the file.
•	Populate the num_list variable by calling the read_file function and passing
    the file name as an argument.
•	Print the entire list
•	Show the lowest number in the list
•	Show the highest number in the list
•	Show the total of the numbers in the list
•	Show the number of lines in the list
•	Show the average of the numbers in the list
"""


def main():
    """
    This is the main function
    """
    # List to store numbers
    numlist = []

    # Variables
    low = 0.0
    high = 0.0
    total = 0.0
    average = 0.0

    # Read numbers from file and print the list
    numlist = read_file('7-1-numbers.txt')
    print()
    print(numlist)
    print()

    low = min(numlist)
    high = max(numlist)
    total = sum(numlist)
    average = total / len(numlist)

    print(f'Low:\t{low}')
    print(f'High:\t{high}')
    print(f'Total:\t{total:,.0f}')
    print(f'Lines:\t{len(numlist):,.0f}')
    print(f'Avg:\t{average:,.2f}\n')


def read_file(file_name):
    """
    read_file that accepts a file path and returns a list of numbers.
    This function will:
    -Include a try block that will handle IOError exceptions.
    -Use the file path argument, open the text file for reading.
    -Read all the lines from the open file.
    -Close the file.
    -Strip the trailing \n from each line and convert the string to an integer.
        Hint: All the list elements must be an int for the math functions
        to work.
    -Return the list of integers read from the file

    """
    numlist = []
    try:
        # Open the file for reading
        infile = open(file_name, 'r', encoding='UTF-8')

        # Read all the lines in the file into a list
        numlist = infile.readlines()

        infile.close()

        # Strip trailing '\n' from all elements of the list
        for nums in range(len(numlist)):
            numlist[nums] = int(numlist[nums].rstrip('\n'))

        return numlist

    except IOError:
        print('The file could not be found')


# Call the main function.
if __name__ == '__main__':
    main()
