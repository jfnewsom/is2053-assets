"""
Chapter 2 - Programming Exercise 1

"""

# Named Constants to hold monthly profit percentages.
JAN_PCT = 0.18
FEB_PCT = 0.13
MAR_PCT = 0.05


def main():
    """
    Variables to hold the sales total and the profit

    """
    jan_tot = 0.0
    feb_tot = 0.0
    mar_tot = 0.0
    qtr_tot = 0.0
    jan_prf = 0.0
    feb_prf = 0.0
    mar_prf = 0.0
    qtr_prf = 0.0

    # Get the amount of projected sales.
    jan_tot = float(input('\nEnter projected sales for Jan: $'))
    feb_tot = float(input('Enter projected sales for Feb: $'))
    mar_tot = float(input('Enter projected sales for Mar: $'))
    qtr_tot = jan_tot + feb_tot + mar_tot

    # Calculate the projected profit.
    jan_prf = jan_tot * JAN_PCT
    feb_prf = feb_tot * FEB_PCT
    mar_prf = mar_tot * MAR_PCT
    qtr_prf = jan_prf + feb_prf + mar_prf

    # Print the projected profit.
    print(f'\nThe projected sales for Q1: ${qtr_tot:,.2f}')
    print(f'The projected profit for Jan: ${jan_prf:,.2f}')
    print(f'The projected profit for Feb: ${feb_prf:,.2f}')
    print(f'The projected profit for Mar: ${mar_prf:,.2f}')
    print(f'The projected profit for Q1: ${qtr_prf:,.2f}\n')


# Call the main function.
if __name__ == '__main__':
    main()
