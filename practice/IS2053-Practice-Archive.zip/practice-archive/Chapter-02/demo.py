"""
This is a docstring

"""

def main():
    """
    The main has a temp variable and then prints it out.

    """
    temp = 98.6
    print(f'The temperature is {temp}\u00b0.')

if __name__ == '__main__':
    main()
