"""
Chapter 2 - Programming Exercise 2

"""
JUN_CEL = 15.7
JUL_CEL = 17.8
AUG_CEL = 17.3


def main():
    """
    Variables to hold the the temperatures

    """

    jun_fah = 0.0
    jul_fah = 0.0
    aug_fah = 0.0

    # Calculate the Fahrenheit equivalent.
    jun_fah = (9.0 / 5.0) * JUN_CEL + 32
    jul_fah = (9.0 / 5.0) * JUL_CEL + 32
    aug_fah = (9.0 / 5.0) * AUG_CEL + 32

    # Display the Fahrenheit temperature.
    print('\nAverage Temperatures in London England')
    print('---------------------------------------')
    print(f'June   {JUN_CEL:.1f}\u00b0 Celsius / '
          + f'{jun_fah:.1f}\u00b0 Fahrenheit')
    print(f'July   {JUL_CEL:.1f}\u00b0 Celsius / '
          + f'{jul_fah:.1f}\u00b0 Fahrenheit')
    print(f'August {AUG_CEL:.1f}\u00b0 Celsius / '
          + f'{aug_fah:.1f}\u00b0 Fahrenheit\n')


# Call the main function.
if __name__ == '__main__':
    main()
