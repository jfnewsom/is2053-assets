"""
Programming Exercise ch8_ex2
"""


def main():
    """
    main function
    """
    # Local variables
    num_sentences = 0
    total_words = 0
    average_words = 0.0
    words = []
    num_upper = 0
    num_lower = 0
    num_digits = 0
    data = ''

    try:
        # Open file text.txt for reading.
        infile = open('8-data.txt', 'r', encoding='UTF-8')

        # Read data into a string.
        data = infile.read()

        # Build a sentences list by splitting the
        # string with the character return
        sentences = data.split('\n')

        # Close the file.
        infile.close()

        # The number of sentences is equal to
        # the length of the list.
        num_sentences = len(sentences)

        # The number of items in each list
        # is the number of words in the sentence.
        for item in sentences:
            words = item.split()
            total_words += len(words)

        # Step through each character in the file.
        # Determine if the character is uppercase,
        # lowercase, a digit, or space, and keep a
        # running total of each.
        for character in data:
            if character.isupper():
                num_upper += 1
            if character.islower():
                num_lower += 1
            if character.isdigit():
                num_digits += 1

        # Calculate average
        average_words = float(total_words) / (num_sentences)

        # Display the totals.
        print(f'\nTotal words: {total_words}')
        print(f'Total sentences: {num_sentences}')
        print(f'Average number of words per line: {average_words}')

        # Display the totals.
        print(f'Uppercase letters: {num_upper}')
        print(f'Lowercase letters: {num_lower}')
        print(f'Digits: {num_digits}\n')

    # Handle any errors that may occur.
    except IOError:
        print('There was an error while opening the file.')


# Call the main function.
if __name__ == '__main__':
    main()
